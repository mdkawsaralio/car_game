import 'dart:async';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:get/get.dart';

class Enemy {
  double x;
  double y;
  Color color;

  Enemy({required this.x, required this.y, required this.color});
}

class GameController extends GetxController {
  final Random random = Random();

  final List<double> lanes = [20, 110, 200, 290];

  RxInt currentLane = 1.obs;
  RxDouble carX = 110.0.obs;

  RxInt score = 0.obs;
  RxBool gameOver = false.obs;
  RxDouble speed = 6.0.obs;

  RxList<Enemy> enemies = <Enemy>[].obs;

  double screenHeight = 800;

  Timer? timer;

  final List<Color> enemyColors = [
    Colors.blue,
    Colors.yellow,
    Colors.green,
    Colors.orange,
    Colors.purple,
    Colors.cyan,
    Colors.pink,
    Colors.teal,
    Colors.amber,
  ];

  @override
  void onInit() {
    super.onInit();
    startGame();
  }

  void setScreenHeight(double height) {
    screenHeight = height;
  }

  void startGame() {
    timer?.cancel();

    enemies.clear();
    addEnemy();

    timer = Timer.periodic(
      const Duration(milliseconds: 30),
      (_) => updateGame(),
    );
  }

  void addEnemy() {
    enemies.add(
      Enemy(
        x: lanes[random.nextInt(lanes.length)],
        y: -(100 + random.nextInt(800)).toDouble(),
        color: enemyColors[random.nextInt(enemyColors.length)],
      ),
    );
  }

  void updateGame() {
    if (gameOver.value) return;

    for (int i = enemies.length - 1; i >= 0; i--) {
      enemies[i].y += speed.value;

      if (enemies[i].y > screenHeight + 100) {
        enemies[i] = Enemy(
          x: lanes[random.nextInt(lanes.length)],
          y: -(100 + random.nextInt(600)).toDouble(),
          color: enemyColors[random.nextInt(enemyColors.length)],
        );

        score.value++;

        if (score.value % 5 == 0) {
          speed.value += 0.5;
        }

        if (score.value % 10 == 0) {
          addEnemy();
        }
      }
    }

    enemies.refresh();
    checkCollision();
  }

  void moveLeft() {
    if (currentLane.value > 0) {
      currentLane.value--;
      carX.value = lanes[currentLane.value];
    }
  }

  void moveRight() {
    if (currentLane.value < lanes.length - 1) {
      currentLane.value++;
      carX.value = lanes[currentLane.value];
    }
  }

  void checkCollision() {
    const double hitBoxWidth = 50;
    const double hitBoxHeight = 50;

    final double playerY = screenHeight - 160;

    final playerRect = Rect.fromLTWH(
      carX.value + 10,
      playerY + 10,
      hitBoxWidth,
      hitBoxHeight,
    );

    for (final enemy in enemies) {
      final enemyRect = Rect.fromLTWH(
        enemy.x + 10,
        enemy.y + 10,
        hitBoxWidth,
        hitBoxHeight,
      );

      if (playerRect.overlaps(enemyRect)) {
        gameOver.value = true;
        timer?.cancel();
        break;
      }
    }
  }

  void restartGame() {
    score.value = 0;
    speed.value = 6;

    currentLane.value = 1;
    carX.value = lanes[1];

    gameOver.value = false;

    startGame();
  }

  @override
  void onClose() {
    timer?.cancel();
    super.onClose();
  }
}
