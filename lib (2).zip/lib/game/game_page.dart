import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'game_controller.dart';

class GamePage extends StatefulWidget {
  const GamePage({super.key});

  @override
  State<GamePage> createState() => _GamePageState();
}

class _GamePageState extends State<GamePage>
    with SingleTickerProviderStateMixin {
  final GameController controller = Get.put(GameController());

  late AnimationController roadAnimation;
  double roadOffset = 0;

  @override
  void initState() {
    super.initState();

    roadAnimation = AnimationController(
      vsync: this,
      duration: const Duration(
        milliseconds: 1000,
      ), // Adjust this duration to alter the road speed feel!
    )..repeat();

    // Note: The setState inside addListener has been completely removed!
  }

  @override
  void dispose() {
    roadAnimation.dispose();
    super.dispose();
  }

  // This single widget replaces both _dashColumn and buildMovingDashedLine
  Widget buildMovingDashedLine(double left, double screenHeight) {
    const double dashHeight = 30.0;
    const double dashSpace = 50.0;
    const double totalPatternHeight =
        dashHeight + dashSpace; // 80.0 pixels per loop cycle

    // Map animation value (0.0 to 1.0) to exactly one loop cycle width (0 to 80)
    final double offset = roadAnimation.value * totalPatternHeight;

    // Calculate exactly how many dashes are needed to fill the screen plus padding for movement
    final int dashCount = (screenHeight / totalPatternHeight).ceil() + 2;

    return Positioned(
      left: left,
      top:
          -totalPatternHeight, // Pull it up slightly so the incoming top dash is hidden off-screen
      bottom: 0,
      child: ClipRect(
        // Ensures any lower overflowing elements are masked perfectly
        child: SizedBox(
          width: 5,
          height: screenHeight + totalPatternHeight,
          child: AnimatedBuilder(
            animation: roadAnimation,
            builder: (context, child) {
              return Transform.translate(
                offset: Offset(0, offset), // Seamless looping offset
                child: Stack(
                  // Using Stack instead of Column handles overflow effortlessly
                  children: List.generate(
                    dashCount,
                    (index) => Positioned(
                      top: index * totalPatternHeight,
                      child: Container(
                        width: 5,
                        height: dashHeight,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final Size size = MediaQuery.of(context).size;
    final double screenWidth = size.width;
    final double screenHeight = size.height;

    controller.setScreenHeight(screenHeight);

    return Scaffold(
      body: SafeArea(
        child: Obx(() {
          if (controller.gameOver.value) {
            if (roadAnimation.isAnimating) {
              roadAnimation.stop();
            }
          } else {
            if (!roadAnimation.isAnimating) {
              roadAnimation.repeat();
            }
          }

          return Stack(
            children: [
              // Road Background
              Container(
                width: screenWidth,
                height: screenHeight,
                color: Colors.grey.shade900,
              ),

              // Moving lane dividers
              buildMovingDashedLine(screenWidth * 0.25, screenHeight),
              buildMovingDashedLine(screenWidth * 0.50, screenHeight),
              buildMovingDashedLine(screenWidth * 0.75, screenHeight),

              // Score
              Positioned(
                top: screenHeight * 0.02,
                left: screenWidth * 0.05,
                child: Text(
                  "Score: ${controller.score.value}",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: screenWidth * 0.065,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),

              // Speed
              Positioned(
                top: screenHeight * 0.08,
                left: screenWidth * 0.05,
                child: Text(
                  "Speed: ${controller.speed.value.toStringAsFixed(1)}",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: screenWidth * 0.045,
                  ),
                ),
              ),

              // Enemy Cars
              ...controller.enemies.map(
                (enemy) => Positioned(
                  left: enemy.x,
                  top: enemy.y,
                  child: Icon(
                    Icons.directions_car,
                    size: screenWidth * 0.18,
                    color: enemy.color,
                  ),
                ),
              ),

              // Player Car
              Positioned(
                bottom: screenHeight * 0.12,
                left: controller.carX.value,
                child: Icon(
                  Icons.directions_car,
                  size: screenWidth * 0.18,
                  color: Colors.red,
                ),
              ),

              // LEFT BUTTON
              Positioned(
                bottom: 35,
                left: 25,
                child: Container(
                  width: 70,
                  height: 70,
                  decoration: BoxDecoration(
                    color: Colors.black.withValues(alpha: 0.6),
                    shape: BoxShape.circle,
                    border: Border.all(color: Colors.white24, width: 2),
                  ),
                  child: IconButton(
                    onPressed: controller.moveLeft,
                    icon: const Icon(
                      Icons.arrow_back_ios_new,
                      color: Colors.white,
                      size: 30,
                    ),
                  ),
                ),
              ),

              // RIGHT BUTTON
              Positioned(
                bottom: 35,
                right: 25,
                child: Container(
                  width: 70,
                  height: 70,
                  decoration: BoxDecoration(
                    color: Colors.black.withValues(alpha: 0.6),
                    shape: BoxShape.circle,
                    border: Border.all(color: Colors.white24, width: 2),
                  ),
                  child: IconButton(
                    onPressed: controller.moveRight,
                    icon: const Icon(
                      Icons.arrow_forward_ios,
                      color: Colors.white,
                      size: 30,
                    ),
                  ),
                ),
              ),

              // Game Over Screen
              if (controller.gameOver.value)
                Container(
                  width: screenWidth,
                  height: screenHeight,
                  color: Colors.black87,
                  child: Center(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          "GAME OVER",
                          style: TextStyle(
                            color: Colors.red,
                            fontSize: screenWidth * 0.10,
                            fontWeight: FontWeight.bold,
                          ),
                        ),

                        const SizedBox(height: 20),

                        Text(
                          "Score: ${controller.score.value}",
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: screenWidth * 0.06,
                          ),
                        ),

                        const SizedBox(height: 20),

                        ElevatedButton(
                          onPressed: () {
                            controller.restartGame();

                            if (!roadAnimation.isAnimating) {
                              roadAnimation.repeat();
                            }
                          },
                          child: const Text("Restart"),
                        ),
                      ],
                    ),
                  ),
                ),
            ],
          );
        }),
      ),
    );
  }
}
