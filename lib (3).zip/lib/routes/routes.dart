class AppRoutes {
  static const String home = '/home';
  static const String game = '/game';

  // Add more routes as needed
}
