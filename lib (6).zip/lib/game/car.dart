import 'dart:math';
import 'package:flutter/material.dart';

class Car {
  double x;
  double y;
  double width;
  double height;
  String asset;
  String type;

  Car({
    required this.x,
    required this.y,
    required this.width,
    required this.height,
    required this.asset,
    required this.type,
  });
}

class PlayerCar extends Car {
  PlayerCar({
    required super.x,
    required super.y,
    required super.width,
    required super.height,
    required super.asset,
  }) : super(type: 'player');
}

class EnemyCar extends Car {
  double speed;
  Color color;

  EnemyCar({
    required super.x,
    required super.y,
    required super.width,
    required super.height,
    required super.asset,
    required super.type,
    required this.speed,
    required this.color,
  });
}

class CarFactory {
  static EnemyCar createEnemy({
    required Random random,
    required List<double> lanes,
    required double playerWidth,
    required double playerHeight,
    required double startY,
    required double baseSpeed,
  }) {
    int lane = random.nextInt(lanes.length);

    double w = playerWidth;
    double h = playerHeight;
    double spd = baseSpeed * 0.5;

    String asset = "lib/assets/car1.png";
    String type = "car";

    switch (random.nextInt(5)) {
      case 0:
        w *= 0.7;
        h *= 0.8;
        spd = baseSpeed * 0.9;
        asset = "lib/assets/motorcycle.png";
        type = "bike";
        break;

      case 1:
        asset = "lib/assets/car1.png";
        type = "car";
        break;

      case 2:
        h *= 1.1;
        asset = "lib/assets/van.png";
        type = "suv";
        break;

      case 3:
        h *= 1.4;
        w *= 1.1;
        spd = baseSpeed * 0.3;
        asset = "lib/assets/truck.png";
        type = "truck";
        break;

      case 4:
        asset = "lib/assets/taxi.png";
        type = "taxi";
        break;
    }

    return EnemyCar(
      x: lanes[lane],
      y: startY,
      width: w,
      height: h,
      asset: asset,
      type: type,
      speed: spd,
      color: Colors.blue,
    );
  }
}

class PlayerCarWidget extends StatelessWidget {
  final double width;
  final double height;
  final bool nitroActive;

  const PlayerCarWidget({
    super.key,
    required this.width,
    required this.height,
    required this.nitroActive,
  });

  @override
  Widget build(BuildContext context) {
    // Scaled to 0.72x to match the small visual size of your enemy asset images
    final scaledWidth = width * 0.72;
    final scaledHeight = height * 0.72;

    return SizedBox(
      width: width,
      height: height,
      child: Center(
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          width: scaledWidth,
          height: scaledHeight,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: nitroActive
                  ? [Colors.cyanAccent, Colors.blue.shade900]
                  : [Colors.red.shade400, Colors.red.shade900],
            ),
            boxShadow: [
              BoxShadow(
                color: nitroActive
                    ? Colors.cyanAccent.withOpacity(.6)
                    : Colors.black.withOpacity(.4),
                blurRadius: nitroActive ? 18 : 6,
                spreadRadius: nitroActive ? 2 : 1,
                offset: const Offset(0, 3),
              ),
            ],
          ),
          child: Stack(
            clipBehavior: Clip.none,
            children: [
              // SIDE MIRRORS
              Positioned(
                top: scaledHeight * 0.22,
                left: -2,
                child: Container(
                  width: 2.5,
                  height: 7,
                  decoration: BoxDecoration(
                    color: nitroActive ? Colors.cyanAccent : Colors.redAccent,
                    borderRadius: BorderRadius.circular(1),
                  ),
                ),
              ),
              Positioned(
                top: scaledHeight * 0.22,
                right: -2,
                child: Container(
                  width: 2.5,
                  height: 7,
                  decoration: BoxDecoration(
                    color: nitroActive ? Colors.cyanAccent : Colors.redAccent,
                    borderRadius: BorderRadius.circular(1),
                  ),
                ),
              ),

              // RACING STRIPES
              Positioned(
                top: 0,
                bottom: 0,
                left: scaledWidth * 0.36,
                width: 2,
                child: Container(color: Colors.white.withOpacity(0.3)),
              ),
              Positioned(
                top: 0,
                bottom: 0,
                left: scaledWidth * 0.48,
                width: 2,
                child: Container(color: Colors.white.withOpacity(0.3)),
              ),

              // FRONT WINDSHIELD
              Positioned(
                top: scaledHeight * 0.20,
                left: scaledWidth * 0.15,
                right: scaledWidth * 0.15,
                height: scaledHeight * 0.18,
                child: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [Colors.black.withOpacity(0.9), Colors.black87],
                    ),
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(6),
                      topRight: Radius.circular(6),
                      bottomLeft: Radius.circular(2),
                      bottomRight: Radius.circular(2),
                    ),
                  ),
                ),
              ),

              // REAR WINDSHIELD
              Positioned(
                top: scaledHeight * 0.62,
                left: scaledWidth * 0.18,
                right: scaledWidth * 0.18,
                height: scaledHeight * 0.12,
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.black87,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),

              // LED HEADLIGHTS
              Positioned(
                top: 2,
                left: scaledWidth * 0.12,
                child: Container(
                  width: scaledWidth * 0.16,
                  height: 3,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(1),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.white.withOpacity(0.8),
                        blurRadius: 3,
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                top: 2,
                right: scaledWidth * 0.12,
                child: Container(
                  width: scaledWidth * 0.16,
                  height: 3,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(1),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.white.withOpacity(0.8),
                        blurRadius: 3,
                      ),
                    ],
                  ),
                ),
              ),

              // REAR TAIL LIGHTS
              Positioned(
                bottom: 2,
                left: scaledWidth * 0.1,
                child: Container(
                  width: scaledWidth * 0.14,
                  height: 2.5,
                  color: Colors.redAccent,
                ),
              ),
              Positioned(
                bottom: 2,
                right: scaledWidth * 0.1,
                child: Container(
                  width: scaledWidth * 0.14,
                  height: 2.5,
                  color: Colors.redAccent,
                ),
              ),

              // DOUBLE NITRO JET FLAMES
              if (nitroActive) ...[
                Positioned(
                  bottom: -10,
                  left: scaledWidth * 0.15,
                  width: scaledWidth * 0.2,
                  height: 12,
                  child: Container(
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [
                          Colors.cyanAccent,
                          Colors.blueAccent,
                          Colors.transparent,
                        ],
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                      ),
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                ),
                Positioned(
                  bottom: -10,
                  right: scaledWidth * 0.15,
                  width: scaledWidth * 0.2,
                  height: 12,
                  child: Container(
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [
                          Colors.cyanAccent,
                          Colors.blueAccent,
                          Colors.transparent,
                        ],
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                      ),
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
