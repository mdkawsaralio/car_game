import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../routes/routes.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0A0A),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              const Color(0xFF0A0A0A),
              const Color(0xFF150808),
              const Color(0xFF0D0D2B),
            ],
          ),
        ),
        child: SafeArea(
          child: Center(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 30),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  // Logo
                  Container(
                    width: 100,
                    height: 100,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: LinearGradient(
                        colors: [Colors.redAccent, Colors.red.shade800],
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.redAccent.withOpacity(0.3),
                          blurRadius: 30,
                          spreadRadius: 5,
                        ),
                      ],
                    ),
                    child: const Icon(
                      Icons.directions_car,
                      color: Colors.white,
                      size: 50,
                    ),
                  ),
                  const SizedBox(height: 20),

                  // Title
                  const Text(
                    'CAR RACING',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 32,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 4,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Feel the speed',
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.3),
                      fontSize: 14,
                      letterSpacing: 6,
                    ),
                  ),
                  const SizedBox(height: 40),

                  // Welcome Text
                  _buildWelcomeText(),
                  const SizedBox(height: 40),

                  // Main Action Button
                  _buildMainAction(),
                  const SizedBox(height: 16),

                  // Secondary Actions
                  _buildSecondaryActions(),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildWelcomeText() {
    final user = FirebaseAuth.instance.currentUser;
    final String name =
        user?.displayName?.split(' ')[0] ??
        user?.email?.split('@').first ??
        'Guest';
    final bool isLoggedIn = user != null;

    return Column(
      children: [
        Text(
          'Welcome back,',
          style: TextStyle(
            color: Colors.white.withOpacity(0.3),
            fontSize: 13,
            letterSpacing: 2,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          name,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 26,
            fontWeight: FontWeight.bold,
            letterSpacing: 1,
          ),
        ),
        const SizedBox(height: 8),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
          decoration: BoxDecoration(
            color: isLoggedIn
                ? Colors.redAccent.withOpacity(0.1)
                : Colors.white.withOpacity(0.05),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Text(
            isLoggedIn ? '🏎️ Ready to race' : '🎮 Playing as Guest',
            style: TextStyle(
              color: isLoggedIn
                  ? Colors.redAccent
                  : Colors.white.withOpacity(0.3),
              fontSize: 12,
              fontWeight: FontWeight.w500,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildMainAction() {
    final user = FirebaseAuth.instance.currentUser;
    final bool isLoggedIn = user != null;

    return SizedBox(
      width: double.infinity,
      height: 56,
      child: ElevatedButton(
        onPressed: () {
          Get.toNamed(AppRoutes.game, arguments: {'isOffline': !isLoggedIn});
        },
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.transparent,
          foregroundColor: Colors.white,
          shadowColor: Colors.transparent,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
          ),
          padding: EdgeInsets.zero,
        ),
        child: Ink(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [Colors.redAccent, Colors.red.shade800],
            ),
            borderRadius: BorderRadius.circular(14),
            boxShadow: [
              BoxShadow(
                color: Colors.redAccent.withOpacity(0.3),
                blurRadius: 20,
                spreadRadius: 5,
              ),
            ],
          ),
          child: Container(
            alignment: Alignment.center,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  isLoggedIn ? '🏁 START RACE' : '🎮 PLAY AS GUEST',
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 2,
                  ),
                ),
                const SizedBox(width: 12),
                const Icon(Icons.play_arrow_rounded, size: 24),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildSecondaryActions() {
    final user = FirebaseAuth.instance.currentUser;
    final bool isLoggedIn = user != null;

    return Row(
      children: [
        Expanded(
          child: OutlinedButton(
            onPressed: () {
              if (isLoggedIn) {
                _logout();
              } else {
                Get.toNamed(AppRoutes.login);
              }
            },
            style: OutlinedButton.styleFrom(
              foregroundColor: Colors.white,
              side: BorderSide(
                color: isLoggedIn
                    ? Colors.white.withOpacity(0.1)
                    : Colors.white.withOpacity(0.2),
              ),
              padding: const EdgeInsets.symmetric(vertical: 14),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(14),
              ),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  isLoggedIn ? Icons.logout_rounded : Icons.login_rounded,
                  size: 18,
                  color: isLoggedIn
                      ? Colors.white.withOpacity(0.4)
                      : Colors.white.withOpacity(0.6),
                ),
                const SizedBox(width: 8),
                Text(
                  isLoggedIn ? 'Logout' : 'Sign In',
                  style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w500,
                    color: isLoggedIn
                        ? Colors.white.withOpacity(0.4)
                        : Colors.white.withOpacity(0.6),
                    letterSpacing: 0.5,
                  ),
                ),
              ],
            ),
          ),
        ),
        if (!isLoggedIn) ...[
          const SizedBox(width: 12),
          Expanded(
            child: OutlinedButton(
              onPressed: () => Get.toNamed(AppRoutes.signup),
              style: OutlinedButton.styleFrom(
                foregroundColor: Colors.white,
                side: BorderSide(color: Colors.redAccent.withOpacity(0.3)),
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14),
                ),
              ),
              child: Text(
                'Sign Up',
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w500,
                  color: Colors.redAccent.withOpacity(0.7),
                  letterSpacing: 0.5,
                ),
              ),
            ),
          ),
        ],
      ],
    );
  }

  void _logout() async {
    try {
      await FirebaseAuth.instance.signOut();
      Get.snackbar(
        'Logged Out',
        'You have been logged out successfully',
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.grey[800],
        colorText: Colors.white,
      );
      // Refresh the page
      Get.offAllNamed(AppRoutes.home);
    } catch (e) {
      print('Logout error: $e');
    }
  }
}
