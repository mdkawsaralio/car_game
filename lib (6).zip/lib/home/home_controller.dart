// File: lib/home/home_controller.dart (Complete)
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../routes/routes.dart';
import '../leaderboard/leaderboard_service.dart';
import '../login/user_data.dart';
import '../login/login.dart'; // ← Add this import

class HomeController extends GetxController {
  final Rx<User?> _firebaseUser = Rx<User?>(FirebaseAuth.instance.currentUser);
  final LeaderboardService _leaderboardService = LeaderboardService();
  final UserDataService _userDataService = UserDataService();

  RxMap<String, dynamic> userStats = <String, dynamic>{}.obs;
  RxBool isLoadingStats = false.obs;

  User? get user => _firebaseUser.value;
  bool get isLoggedIn => _firebaseUser.value != null;

  @override
  void onInit() {
    super.onInit();
    _firebaseUser.bindStream(FirebaseAuth.instance.authStateChanges());
    _firebaseUser.listen((User? user) {
      if (user != null) {
        _loadUserStats();
      } else {
        userStats.value = {};
      }
    });
    if (_firebaseUser.value != null) {
      _loadUserStats();
    }
  }

  Future<void> _loadUserStats() async {
    isLoadingStats.value = true;
    try {
      final stats = await _leaderboardService.getCurrentPlayerStats();
      if (stats != null) {
        userStats.value = {
          'bestScore': stats.bestScore,
          'totalCoins': stats.totalCoins,
          'gamesPlayed': stats.gamesPlayed,
        };
      } else {
        final highScore = await _userDataService.getHighScore();
        final coins = await _userDataService.getCoins();
        userStats.value = {
          'bestScore': highScore,
          'totalCoins': coins,
          'gamesPlayed': 0,
        };
      }
    } catch (e) {
      final highScore = await _userDataService.getHighScore();
      final coins = await _userDataService.getCoins();
      userStats.value = {
        'bestScore': highScore,
        'totalCoins': coins,
        'gamesPlayed': 0,
      };
    }
    isLoadingStats.value = false;
  }

  void playOffline() {
    Get.toNamed(AppRoutes.game, arguments: {'isOffline': true});
  }

  void handleAuthAction() async {
    if (isLoggedIn) {
      try {
        await FirebaseAuth.instance.signOut();
        _firebaseUser.value = null;
        userStats.value = {};
        Get.snackbar(
          'Logged Out',
          'You have been logged out successfully',
          snackPosition: SnackPosition.BOTTOM,
          backgroundColor: Colors.grey[800],
          colorText: Colors.white,
        );
      } catch (e) {
        print('Logout error: $e');
      }
    } else {
      try {
        await Get.toNamed(AppRoutes.login);
      } catch (e) {
        Get.to(() => const LoginPage());
      }
    }
  }
}
