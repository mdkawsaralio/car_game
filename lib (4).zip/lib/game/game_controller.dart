import 'dart:async';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'car.dart';

class Coin {
  double x;
  double y;

  Coin({required this.x, required this.y});
}

class RoadDecoration {
  double x;
  double y;
  IconData icon;
  Color color;

  RoadDecoration({
    required this.x,
    required this.y,
    required this.icon,
    required this.color,
  });
}

class GameController extends GetxController {
  final Random random = Random();
  late SharedPreferences _prefs;

  final List<double> lanes = [0.0, 0.0, 0.0, 0.0];

  RxInt currentLane = 1.obs;
  RxDouble carX = 0.0.obs;

  double screenWidth = 360;
  double screenHeight = 800;

  double playerWidth = 45;
  double playerHeight = 85;

  // Visual layout boundaries anchor for collision grid alignment
  double get playerVisualY => screenHeight - 140 - playerHeight;

  RxInt score = 0.obs;
  RxInt coins = 0.obs;
  RxInt runCoinsGained = 0.obs;
  RxInt highScore = 0.obs;
  RxDouble distance = 0.0.obs;

  RxBool gameOver = false.obs;

  RxDouble speed = 6.0.obs;
  double normalSpeedBase = 6.0;
  double nitroSpeedMultiplier = 2.0;

  RxBool nitroActive = false.obs;

  RxList<EnemyCar> enemies = <EnemyCar>[].obs;
  RxList<Coin> coinList = <Coin>[].obs;
  RxList<RoadDecoration> decorations = <RoadDecoration>[].obs;

  int lastSpeedIncrementScore = 0;

  @override
  void onInit() {
    super.onInit();
    _initStorageAndStart();
  }

  Future<void> _initStorageAndStart() async {
    _prefs = await SharedPreferences.getInstance();
    highScore.value = _prefs.getInt('high_score') ?? 0;
    coins.value = _prefs.getInt('total_coins') ?? 0;
    startGame();
  }

  void setupPlayingField(double width, double height) {
    if (screenWidth == width && screenHeight == height && lanes[0] != 0.0) {
      return;
    }

    screenWidth = width;
    screenHeight = height;

    playerWidth = screenWidth * 0.11;
    playerHeight = playerWidth * 1.8;

    double start = screenWidth * 0.125;
    double laneWidth = (screenWidth * 0.75) / 4;

    for (int i = 0; i < 4; i++) {
      lanes[i] = start + (i * laneWidth) + (laneWidth / 2) - (playerWidth / 2);
    }

    carX.value = lanes[currentLane.value];
  }

  void startGame() {
    enemies.clear();
    coinList.clear();
    decorations.clear();

    distance.value = 0;
    score.value = 0;
    runCoinsGained.value = 0;

    normalSpeedBase = 6.0;
    speed.value = normalSpeedBase;
    lastSpeedIncrementScore = 0;

    gameOver.value = false;
    nitroActive.value = false;

    _generateDecorations();
    _spawnEnemy();
    _spawnCoin();
  }

  /// NATIVE TICKER SYNC FRAME RATE ENGINE Loop Execution
  void updateGameFrame(double deltaTime) {
    if (gameOver.value) return;

    // Linearly maps metric progression metrics to actual elapsed time physics frames
    distance.value += speed.value * deltaTime * 4.5;
    score.value = distance.value ~/ 10;

    // SPRINT VELOCITY PROGRESSION: Speeds up base speed slightly every 20 score milestones
    if (score.value > 0 &&
        score.value % 20 == 0 &&
        score.value != lastSpeedIncrementScore) {
      lastSpeedIncrementScore = score.value;
      normalSpeedBase += 0.4;
      if (!nitroActive.value) speed.value = normalSpeedBase;
    }

    // DYNAMIC TRAFFIC CAPACITY: Multiplies highway occupants based on performance tiers
    if (score.value >= 30 && enemies.length < 2) {
      _spawnEnemyWithSafetyCheck();
    }
    if (score.value >= 80 && enemies.length < 3) {
      _spawnEnemyWithSafetyCheck();
    }

    // Multiply structural adjustments by scale factor constants to normalize frame variants
    _moveEnemies(deltaTime * 30);
    _handleEnemyOvertaking();
    _moveCoins(deltaTime * 30);
    _moveDecorationsFrame(deltaTime * 30);
    _checkCollision(deltaTime);
  }

  // ANTI-COLLISION SPAWNING: Stops vehicles from popping in on top of existing ones
  void _spawnEnemyWithSafetyCheck() {
    double spawnY = -(200 + random.nextDouble() * 250);
    EnemyCar tentativeEnemy = _createEnemy(spawnY);

    bool spaceIsOccupied = enemies.any(
      (existingEnemy) =>
          existingEnemy.x == tentativeEnemy.x &&
          (existingEnemy.y - tentativeEnemy.y).abs() < 180,
    );

    if (spaceIsOccupied) {
      for (double laneX in lanes) {
        bool laneOccupied = enemies.any(
          (e) => e.x == laneX && (e.y - spawnY).abs() < 180,
        );
        if (!laneOccupied) {
          tentativeEnemy.x = laneX;
          break;
        }
      }
    }

    enemies.add(tentativeEnemy);
  }

  void _spawnEnemy() {
    _spawnEnemyWithSafetyCheck();
  }

  EnemyCar _createEnemy(double startY) {
    return CarFactory.createEnemy(
      random: random,
      lanes: lanes,
      playerWidth: playerWidth,
      playerHeight: playerHeight,
      startY: startY,
      baseSpeed: normalSpeedBase,
    );
  }

  void _moveEnemies(double f) {
    for (int i = enemies.length - 1; i >= 0; i--) {
      enemies[i].y += (speed.value - enemies[i].speed) * f;

      if (enemies[i].y > screenHeight + 100) {
        enemies.removeAt(i);
        _spawnEnemyWithSafetyCheck();
      }
    }
    enemies.refresh();
  }

  // ACTIVE TRAFFIC OVERTAKING LOGIC: Handles lane changes if a fast car approaches a slower one
  void _handleEnemyOvertaking() {
    for (int i = 0; i < enemies.length; i++) {
      for (int j = 0; j < enemies.length; j++) {
        if (i == j) continue;

        EnemyCar trailing = enemies[i];
        EnemyCar leading = enemies[j];

        if (trailing.x == leading.x &&
            trailing.y > leading.y - 160 &&
            trailing.y < leading.y &&
            trailing.speed < leading.speed) {
          int currentLaneIndex = lanes.indexOf(trailing.x);
          if (currentLaneIndex == -1) continue;

          int leftLane = currentLaneIndex - 1;
          int rightLane = currentLaneIndex + 1;
          bool shifted = false;

          if (leftLane >= 0) {
            double targetX = lanes[leftLane];
            bool safe = !enemies.any(
              (e) => e.x == targetX && (e.y - trailing.y).abs() < 160,
            );
            if (safe) {
              trailing.x = targetX;
              shifted = true;
            }
          }

          if (!shifted && rightLane < lanes.length) {
            double targetX = lanes[rightLane];
            bool safe = !enemies.any(
              (e) => e.x == targetX && (e.y - trailing.y).abs() < 160,
            );
            if (safe) {
              trailing.x = targetX;
            }
          }
        }
      }
    }
  }

  void _spawnCoin() {
    int lane = random.nextInt(lanes.length);
    coinList.add(
      Coin(
        x: lanes[lane] + playerWidth / 2 - 12,
        y: -(100 + random.nextDouble() * 300),
      ),
    );
  }

  void _moveCoins(double f) {
    for (int i = coinList.length - 1; i >= 0; i--) {
      coinList[i].y += speed.value * f;
      if (coinList[i].y > screenHeight + 50) {
        coinList.removeAt(i);
      }
    }
    if (coinList.length < 2) _spawnCoin();
    coinList.refresh();
  }

  void _generateDecorations() {
    for (int i = 0; i < 6; i++) {
      decorations.add(
        RoadDecoration(
          x: random.nextBool() ? random.nextDouble() * 40 : screenWidth - 50,
          y: random.nextDouble() * screenHeight,
          icon: Icons.park,
          color: Colors.green,
        ),
      );
    }
  }

  void _moveDecorationsFrame(double f) {
    for (int i = 0; i < decorations.length; i++) {
      decorations[i].y += speed.value * f;
      if (decorations[i].y > screenHeight) {
        decorations[i].y = -(20 + random.nextDouble() * 50);
        decorations[i].x = random.nextBool()
            ? random.nextDouble() * 40
            : screenWidth - 50;
      }
    }
    decorations.refresh();
  }
  // IMPROVED COLLISION with smaller, centered hitboxes & accurate swept test
  void _checkCollision(double deltaTime) {
    // Hitbox is 80% of the visual car size – makes collision fairer
    const double hitboxScale = 0.8;

    // ----- Player hitbox -----
    final double visualCarWidth = playerWidth * 0.72;
    final double visualCarHeight = playerHeight * 0.72;
    final double hitboxWidth = visualCarWidth * hitboxScale;
    final double hitboxHeight = visualCarHeight * hitboxScale;

    final double visualLeftOffset =
        carX.value + (playerWidth - visualCarWidth) / 2;
    final double visualTopOffset =
        playerVisualY + (playerHeight - visualCarHeight) / 2;

    final double hitboxLeft =
        visualLeftOffset + (visualCarWidth - hitboxWidth) / 2;
    final double hitboxTop =
        visualTopOffset + (visualCarHeight - hitboxHeight) / 2;

    final playerRect = Rect.fromLTWH(
      hitboxLeft,
      hitboxTop,
      hitboxWidth,
      hitboxHeight,
    );

    // ----- Enemy hitbox (also scaled) -----
    for (final e in enemies) {
      final double enemyHitboxWidth = e.width * hitboxScale;
      final double enemyHitboxHeight = e.height * hitboxScale;
      final double enemyHitboxLeft = e.x + (e.width - enemyHitboxWidth) / 2;
      final double enemyHitboxTop = e.y + (e.height - enemyHitboxHeight) / 2;

      // Relative speed and displacement over this frame (same multiplier as _moveEnemies)
      final double relativeSpeed = speed.value - e.speed;
      final double displacement = relativeSpeed * deltaTime * 30;

      final sweptEnemyRect = Rect.fromLTRB(
        enemyHitboxLeft,
        displacement > 0 ? enemyHitboxTop - displacement : enemyHitboxTop,
        enemyHitboxLeft + enemyHitboxWidth,
        displacement > 0
            ? enemyHitboxTop + enemyHitboxHeight
            : enemyHitboxTop + enemyHitboxHeight - displacement,
      );

      if (playerRect.overlaps(sweptEnemyRect)) {
        _gameOver();
        return;
      }
    }

    // ----- Coins (unchanged, they can keep full size) -----
    for (int i = coinList.length - 1; i >= 0; i--) {
      final coinRect = Rect.fromLTWH(coinList[i].x, coinList[i].y, 24, 24);
      if (playerRect.overlaps(coinRect)) {
        coins.value++;
        runCoinsGained.value++;
        coinList.removeAt(i);
      }
    }
  }

  void moveLeft() {
    if (currentLane.value > 0 && !gameOver.value) {
      currentLane.value--;
      carX.value = lanes[currentLane.value];
    }
  }

  void moveRight() {
    if (currentLane.value < lanes.length - 1 && !gameOver.value) {
      currentLane.value++;
      carX.value = lanes[currentLane.value];
    }
  }

  void setNitro(bool value) {
    if (gameOver.value) return;
    nitroActive.value = value;
    speed.value = value
        ? normalSpeedBase * nitroSpeedMultiplier
        : normalSpeedBase;
  }

  void _gameOver() async {
    gameOver.value = true;
    if (score.value > highScore.value) {
      highScore.value = score.value;
      await _prefs.setInt('high_score', highScore.value);
    }
    await _prefs.setInt('total_coins', coins.value);
  }

  // COIN BASED SHOP LIFE EXTRA RECOVERY REVIVE METHOD
  bool buyLifeBack() {
    if (coins.value >= 500) {
      coins.value -= 500;
      _prefs.setInt('total_coins', coins.value);

      // Sweep track artifacts to prevent immediate death loop upon revival
      enemies.clear();
      coinList.clear();
      _spawnEnemyWithSafetyCheck();
      _spawnCoin();

      gameOver.value = false;
      nitroActive.value = false;
      speed.value = normalSpeedBase;
      return true;
    }
    return false;
  }

  void restartGame() {
    startGame();
  }
}
