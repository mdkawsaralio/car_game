import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'home_controller.dart';
import 'package:car_game5/routes/routes.dart'; // ✅ added missing import

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    final HomeController controller = Get.put(HomeController());

    return Scaffold(
      backgroundColor: Colors.grey.shade900,
      body: Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 30),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(
                Icons.directions_car,
                size: 120,
                color: Colors.redAccent,
              ),
              const SizedBox(height: 20),
              const Text(
                'CAR GAME',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 40,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 3,
                ),
              ),
              const SizedBox(height: 60),

              // Dynamic Primary Action Button
              Obx(
                () => SizedBox(
                  width: 250,
                  height: 55,
                  child: ElevatedButton(
                    onPressed: () {
                      if (controller.isLoggedIn) {
                        // Play as Authenticated User
                        Get.toNamed(
                          AppRoutes.game,
                          arguments: {'isOffline': false},
                        );
                      } else {
                        // Action for non-logged-in user on button 1: Open login screen
                        controller.handleAuthAction();
                      }
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.redAccent,
                      foregroundColor: Colors.white,
                      elevation: 8,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15),
                      ),
                    ),
                    child: Text(
                      controller.isLoggedIn ? 'PLAY' : 'LOGIN',
                      style: const TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 1.5,
                      ),
                    ),
                  ),
                ),
              ),

              const SizedBox(height: 20),

              // Dynamic Secondary Action Button
              Obx(
                () => SizedBox(
                  width: 250,
                  height: 55,
                  child: OutlinedButton(
                    onPressed: () {
                      if (controller.isLoggedIn) {
                        // If logged in, this button turns into a Logout option
                        controller.handleAuthAction();
                      } else {
                        // If guest, plays explicitly offline/guest mode
                        Get.toNamed(
                          AppRoutes.game,
                          arguments: {'isOffline': true},
                        );
                      }
                    },
                    style: OutlinedButton.styleFrom(
                      foregroundColor: Colors.white,
                      side: const BorderSide(color: Colors.white54, width: 2),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15),
                      ),
                    ),
                    child: Text(
                      controller.isLoggedIn ? 'LOGOUT' : 'PLAY AS GUEST',
                      style: const TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 1.5,
                      ),
                    ),
                  ),
                ),
              ),

              // User status display
              Obx(
                () => controller.isLoggedIn
                    ? Padding(
                        padding: const EdgeInsets.only(top: 20),
                        child: Text(
                          'Logged in as: ${controller.user?.email}',
                          style: const TextStyle(
                            color: Colors.grey,
                            fontSize: 14,
                          ),
                        ),
                      )
                    : const SizedBox.shrink(),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
