import 'package:car_game5/login/login.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../routes/routes.dart';

class HomeController extends GetxController {
  final Rx<User?> _firebaseUser = Rx<User?>(FirebaseAuth.instance.currentUser);

  User? get user => _firebaseUser.value;
  bool get isLoggedIn => _firebaseUser.value != null;

  @override
  void onInit() {
    super.onInit();
    _firebaseUser.bindStream(FirebaseAuth.instance.authStateChanges());
  }

  void playOffline() {
    Get.toNamed(AppRoutes.game, arguments: {'isOffline': true});
  }

  void handleAuthAction() async {
    if (isLoggedIn) {
      try {
        await FirebaseAuth.instance.signOut();
        // Update the user state
        _firebaseUser.value = null;
      } catch (e) {
        print('Logout error: $e');
        Get.snackbar(
          'Error',
          'Failed to logout: $e',
          snackPosition: SnackPosition.BOTTOM,
          backgroundColor: Colors.red,
          colorText: Colors.white,
        );
      }
    } else {
      // Navigate to login page with proper error handling
      try {
        await Get.toNamed(AppRoutes.login);
      } catch (e) {
        print('Navigation error: $e');
        // Fallback navigation
        Get.to(() => const LoginPage());
      }
    }
  }
}
