import 'package:car_game5/home/home.dart';
import 'package:car_game5/routes/routes.dart';
import 'package:car_game5/login/login.dart';
import 'package:get/get.dart';
import '../game/game_page.dart';

class AppPages {
  static List<GetPage<dynamic>> routes = [
    GetPage(name: AppRoutes.home, page: () => const HomePage()),
    GetPage(name: AppRoutes.game, page: () => const GamePage()),
    GetPage(name: AppRoutes.login, page: () => const LoginPage()),
  ];
}
