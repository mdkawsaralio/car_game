import 'package:audioplayers/audioplayers.dart';
import 'package:get/get.dart';

class SoundService extends GetxService {
  // ============================================================
  // FIXED PLAYER POOL - 6 Players Total (Added turbo loop)
  // ============================================================
  final AudioPlayer _carPlayer = AudioPlayer(); // Engine loop
  final AudioPlayer _musicPlayer = AudioPlayer(); // Home music loop
  final AudioPlayer _coinPlayer = AudioPlayer(); // Coin SFX
  final AudioPlayer _turboPlayer = AudioPlayer(); // Turbo SFX (loop)
  final AudioPlayer _crashPlayer = AudioPlayer(); // Crash SFX
  final AudioPlayer _turboLoopPlayer =
      AudioPlayer(); // Turbo loop (separate from SFX)

  // ============================================================
  // SETTINGS
  // ============================================================
  RxBool isSoundEnabled = true.obs;
  RxBool isMusicEnabled = true.obs;

  // ============================================================
  // SOUND PATHS
  // ============================================================
  static const String carSound = 'sound/car.mp3';
  static const String crushSound = 'sound/crush.mp3';
  static const String turboSound = 'sound/turbo.mp3';
  static const String homePageSound = 'sound/home_page.mp3';
  static const String coinSound = 'sound/coin.mp3';

  // ============================================================
  // STATE TRACKING
  // ============================================================
  bool _isCarPlaying = false;
  bool _isMusicPlaying = false;
  bool _isTurboPlaying = false;
  bool _isInitialized = false;

  // ============================================================
  // LIFECYCLE
  // ============================================================
  @override
  void onInit() {
    super.onInit();
    _loadSettings();
    _setupAudioContexts();
  }

  @override
  void onClose() {
    _carPlayer.dispose();
    _musicPlayer.dispose();
    _coinPlayer.dispose();
    _turboPlayer.dispose();
    _crashPlayer.dispose();
    _turboLoopPlayer.dispose();
    super.onClose();
  }

  Future<void> _loadSettings() async {
    // Load from SharedPreferences if needed
  }

  // ============================================================
  // SETUP AUDIO CONTEXTS - CRITICAL FOR ANDROID
  // ============================================================
  void _setupAudioContexts() {
    try {
      // Car Engine - Game music, no focus
      _carPlayer.setAudioContext(
        AudioContext(
          android: AudioContextAndroid(
            isSpeakerphoneOn: false,
            stayAwake: false,
            contentType: AndroidContentType.music,
            usageType: AndroidUsageType.game,
            audioFocus: AndroidAudioFocus.none,
          ),
        ),
      );

      // Background Music - Game music, no focus
      _musicPlayer.setAudioContext(
        AudioContext(
          android: AudioContextAndroid(
            isSpeakerphoneOn: false,
            stayAwake: false,
            contentType: AndroidContentType.music,
            usageType: AndroidUsageType.game,
            audioFocus: AndroidAudioFocus.none,
          ),
        ),
      );

      // SFX Players - Sound effects, no focus, low latency
      final sfxContext = AudioContext(
        android: AudioContextAndroid(
          isSpeakerphoneOn: false,
          stayAwake: false,
          contentType: AndroidContentType.sonification,
          usageType: AndroidUsageType.game,
          audioFocus: AndroidAudioFocus.none,
        ),
      );

      _coinPlayer.setAudioContext(sfxContext);
      _turboPlayer.setAudioContext(sfxContext);
      _crashPlayer.setAudioContext(sfxContext);
      _turboLoopPlayer.setAudioContext(sfxContext);

      print('✅ Audio contexts configured (audioFocus: none)');
    } catch (e) {
      print('❌ Audio context error: $e');
    }
  }

  // ============================================================
  // PRELOAD SOUNDS - Call from main.dart
  // ============================================================
  Future<void> preloadSounds() async {
    if (_isInitialized) return;

    try {
      print('🎵 Preloading sounds with optimized settings...');

      // Set player modes for low latency
      await _carPlayer.setPlayerMode(PlayerMode.lowLatency);
      await _musicPlayer.setPlayerMode(PlayerMode.mediaPlayer);
      await _coinPlayer.setPlayerMode(PlayerMode.lowLatency);
      await _turboPlayer.setPlayerMode(PlayerMode.lowLatency);
      await _crashPlayer.setPlayerMode(PlayerMode.lowLatency);
      await _turboLoopPlayer.setPlayerMode(PlayerMode.lowLatency);

      // Preload all sounds
      await Future.wait([
        _carPlayer.setSource(AssetSource(carSound)),
        _musicPlayer.setSource(AssetSource(homePageSound)),
        _coinPlayer.setSource(AssetSource(coinSound)),
        _turboPlayer.setSource(AssetSource(turboSound)),
        _crashPlayer.setSource(AssetSource(crushSound)),
        _turboLoopPlayer.setSource(AssetSource(turboSound)),
      ]);

      _isInitialized = true;
      print('✅ All 6 sounds preloaded successfully');
    } catch (e) {
      print('❌ Preload error: $e');
    }
  }

  void toggleSound(bool enabled) {
    isSoundEnabled.value = enabled;
    if (!enabled) {
      stopAllSounds();
    }
  }

  void toggleMusic(bool enabled) {
    isMusicEnabled.value = enabled;
    if (enabled) {
      playHomePageMusic();
    } else {
      stopHomePageMusic();
    }
  }

  // ============================================================
  // CAR ENGINE - Player 1 (Loops)
  // ============================================================
  Future<void> playCarSound() async {
    if (!isSoundEnabled.value || _isCarPlaying) return;

    try {
      await _carPlayer.stop();
      await _carPlayer.setReleaseMode(ReleaseMode.loop);
      await _carPlayer.play(AssetSource(carSound), volume: 0.3);
      _isCarPlaying = true;
      print('🚗 Car sound started');
    } catch (e) {
      _isCarPlaying = false;
      print('❌ Car sound error: $e');
    }
  }

  void stopCarSound() {
    try {
      _carPlayer.stop();
      _isCarPlaying = false;
      print('🛑 Car sound stopped');
    } catch (_) {}
  }

  void pauseCarSound() {
    try {
      _carPlayer.pause();
      _isCarPlaying = false;
      print('⏸️ Car sound paused');
    } catch (_) {}
  }

  Future<void> resumeCarSound() async {
    if (!isSoundEnabled.value) return;

    try {
      await _carPlayer.resume();
      _isCarPlaying = true;
      print('▶️ Car sound resumed');
    } catch (_) {
      playCarSound();
    }
  }

  bool get isCarPlaying => _isCarPlaying;

  // ============================================================
  // TURBO SOUND - Player 2 (Loops while held)
  // ============================================================
  Future<void> startTurboSound() async {
    if (!isSoundEnabled.value || _isTurboPlaying) return;

    try {
      await _turboLoopPlayer.stop();
      await _turboLoopPlayer.setReleaseMode(ReleaseMode.loop);
      await _turboLoopPlayer.play(AssetSource(turboSound), volume: 0.5);
      _isTurboPlaying = true;
      print('⚡ Turbo sound STARTED (loop)');
    } catch (e) {
      _isTurboPlaying = false;
      print('❌ Turbo start error: $e');
    }
  }

  Future<void> stopTurboSound() async {
    try {
      await _turboLoopPlayer.stop();
      _isTurboPlaying = false;
      print('⚡ Turbo sound STOPPED');
    } catch (e) {
      print('❌ Turbo stop error: $e');
    }
  }

  bool get isTurboPlaying => _isTurboPlaying;

  // ============================================================
  // COIN SOUND - Player 3 (Play Once)
  // ============================================================
  Future<void> playCoinSound() async {
    if (!isSoundEnabled.value) return;

    try {
      await _coinPlayer.stop();
      await _coinPlayer.setReleaseMode(ReleaseMode.release);
      await _coinPlayer.play(AssetSource(coinSound), volume: 0.4);
      print('🪙 Coin sound (car continues)');
    } catch (e) {
      print('❌ Coin sound error: $e');
    }
  }

  // ============================================================
  // CRASH SOUND - Player 4 (Play Once)
  // ============================================================
  Future<void> playCrushSound() async {
    if (!isSoundEnabled.value) return;

    try {
      await _crashPlayer.stop();
      await _crashPlayer.setReleaseMode(ReleaseMode.release);
      await _crashPlayer.play(AssetSource(crushSound), volume: 0.7);
      print('💥 Crash sound');
    } catch (e) {
      print('❌ Crash sound error: $e');
    }
  }

  // ============================================================
  // BACKGROUND MUSIC - Player 5 (Loops)
  // ============================================================
  Future<void> playHomePageMusic() async {
    if (!isMusicEnabled.value || _isMusicPlaying) return;

    try {
      await _musicPlayer.stop();
      await _musicPlayer.setReleaseMode(ReleaseMode.loop);
      await _musicPlayer.play(AssetSource(homePageSound), volume: 0.2);
      _isMusicPlaying = true;
      print('🎵 Home music started');
    } catch (e) {
      _isMusicPlaying = false;
      print('❌ Music error: $e');
    }
  }

  void stopHomePageMusic() {
    try {
      _musicPlayer.stop();
      _isMusicPlaying = false;
      print('🎵 Home music stopped');
    } catch (_) {}
  }

  void pauseHomePageMusic() {
    try {
      _musicPlayer.pause();
      _isMusicPlaying = false;
    } catch (_) {}
  }

  Future<void> resumeHomePageMusic() async {
    if (!isMusicEnabled.value) return;

    try {
      await _musicPlayer.resume();
      _isMusicPlaying = true;
    } catch (_) {
      playHomePageMusic();
    }
  }

  bool get isMusicPlaying => _isMusicPlaying;

  // ============================================================
  // VOLUME CONTROL
  // ============================================================
  Future<void> setCarVolume(double volume) async {
    await _carPlayer.setVolume(volume.clamp(0.0, 1.0));
  }

  Future<void> setMusicVolume(double volume) async {
    await _musicPlayer.setVolume(volume.clamp(0.0, 1.0));
  }

  Future<void> setSFXVolume(double volume) async {
    await _coinPlayer.setVolume(volume.clamp(0.0, 1.0));
    await _turboPlayer.setVolume(volume.clamp(0.0, 1.0));
    await _crashPlayer.setVolume(volume.clamp(0.0, 1.0));
    await _turboLoopPlayer.setVolume(volume.clamp(0.0, 1.0));
  }

  // ============================================================
  // STOP ALL SOUNDS
  // ============================================================
  void stopAllSounds() {
    try {
      _carPlayer.stop();
      _musicPlayer.stop();
      _coinPlayer.stop();
      _turboPlayer.stop();
      _crashPlayer.stop();
      _turboLoopPlayer.stop();
      _isCarPlaying = false;
      _isMusicPlaying = false;
      _isTurboPlaying = false;
      print('🛑 All sounds stopped');
    } catch (_) {}
  }

  bool get isInitialized => _isInitialized;
}
