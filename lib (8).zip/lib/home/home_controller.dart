import 'package:car_game5/login/login.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../routes/routes.dart';
import '../sound/sound_service.dart';

class HomeController extends GetxController {
  final Rx<User?> _firebaseUser = Rx<User?>(FirebaseAuth.instance.currentUser);

  final SoundService _soundService = Get.find<SoundService>();

  User? get user => _firebaseUser.value;
  bool get isLoggedIn => _firebaseUser.value != null;

  @override
  void onInit() {
    super.onInit();
    _firebaseUser.bindStream(FirebaseAuth.instance.authStateChanges());

    // Play home page music when home screen opens
    _playHomeMusic();
  }

  @override
  void onClose() {
    _soundService.stopHomePageMusic();
    super.onClose();
  }

  // Called when returning from game
  void onResume() {
    _playHomeMusic();
  }

  void _playHomeMusic() {
    // Stop any game sounds first
    _soundService.stopCarSound();
    _soundService.stopTurboSound();
    _soundService.stopAllSounds();

    // Play home music if not already playing
    if (!_soundService.isMusicPlaying) {
      _soundService.playHomePageMusic();
      print('🎵 Home music resumed');
    }
  }

  void playOffline() {
    // Guest mode - NO internet checks
    Get.toNamed(AppRoutes.game, arguments: {'isOffline': true});
  }

  void handleAuthAction() async {
    if (isLoggedIn) {
      try {
        await FirebaseAuth.instance.signOut();
        _firebaseUser.value = null;

        Get.snackbar(
          'Logged Out',
          'You have been logged out successfully',
          snackPosition: SnackPosition.BOTTOM,
          backgroundColor: Colors.grey[800],
          colorText: Colors.white,
        );
      } catch (e) {
        print('Logout error: $e');
      }
    } else {
      // Login mode - WILL check internet (handled in login page)
      try {
        await Get.toNamed(AppRoutes.login);
      } catch (e) {
        Get.to(() => const LoginPage());
      }
    }
  }
}
